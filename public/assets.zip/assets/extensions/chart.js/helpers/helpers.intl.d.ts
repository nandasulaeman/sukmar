export declare function formatNumber(num: number, locale: string, options?: Intl.NumberFormatOptions): string;
